# nonebot-plugin-acc-calculate
malody考段计算单曲acc
## 使用方式
聊天框输入  
`/acc`

然后按步骤提供信息

支持并发
> 提示：你可能还需要输入命令前缀

![Image text](https://github.com/ohdmire/nonebot-plugin-acc-calculate/blob/main/resource/1.png)

![Image text](https://github.com/ohdmire/nonebot-plugin-acc-calculate/blob/main/resource/2.png)


## 关于
目前支持malody v2 v3段位 reform段位

其他段位看使用人数情况加入