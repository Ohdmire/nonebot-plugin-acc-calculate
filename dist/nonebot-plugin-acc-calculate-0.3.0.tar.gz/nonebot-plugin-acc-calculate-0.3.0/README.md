# nonebot-plugin-acc-calculate
malody段位计算单曲acc
## 使用方式
聊天框输入  
`/acc`  
然后按步骤提供信息
## 关于
目前支持malody v2 v3段位
reform段位